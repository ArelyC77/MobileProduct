//
//  Fact.swift
//  MyProduct
//
//  Created by Arely Correa on 1/21/24.
//

import UIKit

struct Fact {
    let info: String
    let image: UIImage
}
