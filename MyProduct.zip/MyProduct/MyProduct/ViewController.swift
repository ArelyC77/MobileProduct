//
//  ViewController.swift
//  MyProduct
//
//  Created by Arely Correa on 1/21/24.
//

import UIKit

class ViewController: UIViewController {
    
    let backstory = Fact(info: "Gallimimus", image: UIImage(named: "Zoro BS")! )
    let weakness = Fact(info: "My weakness Is that I have no sense of direction", image: UIImage(named: "Zoro BS")! )
    let lift = Fact(info: "I can lift more than Sanji", image: UIImage(named: "Zoro BS")! )
    //    let stegosaurus = Dinosaur(name: "Stegosaurus", image: UIImage(named: "stegosaurus")!, type: "stegosaur", weight: 4990, height: 4.0, diet: "Herbivore", era: "Late Jurassic", region: "North America", speed: 10)
    //    let tyrannosaurus = Dinosaur(name: "Tyrannosaurus Rex", image: UIImage(named: "tyrannosaurus")!, type: "theropod", weight: 7030, height: 3.6, diet: "Carnivore", era: "Jurrasic/Cretaceous", region: "North America", speed: 15)
    //    let brachiosaurus = Dinosaur(name: "Brachiosaurus", image: UIImage(named: "brachiosaurus")!, type: "sauropod", weight: 60000, height: 12.5, diet: "Omnivore", era: "Late Jurassic", region: "North America", speed: 6)
    
    // Array for storing Dinosaurs
    var facts: [Fact] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        facts = [backstory, weakness, lift]
    }
    
    
    @IBAction func didTapBackstory(_ sender: UITapGestureRecognizer) {
        if let tappedView = sender.view {
            performSegue(withIdentifier: "detailSegue", sender: tappedView)
        }
    }
    
    @IBAction func didTapWeakness(_ sender: UITapGestureRecognizer) {
        if let tappedView = sender.view {
            performSegue(withIdentifier: "detailSegue2", sender: tappedView)
        }
    }
    
    @IBAction func didTapList(_ sender: UITapGestureRecognizer) {
        if let tappedView = sender.view {
            performSegue(withIdentifier: "detailSegue3", sender: tappedView)
        }
    }
    
    
    
    
}
