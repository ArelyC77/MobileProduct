//
//  DetailViewController.swift
//  MyProduct
//
//  Created by Arely Correa on 1/21/24.
//

import UIKit

class DetailViewController: UIViewController {

    var fact: Fact?
    
    @IBOutlet weak var zoroInfo: UILabel!
    
    @IBOutlet weak var zoroImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let fact = fact {
               print(fact.info)
           }
        
        
//        if let fact = fact {
//            // Configure the dinosaur image and dynamic labels
//            zoroImage.image = fact.image
//            zoroInfo.text = fact.info
//            
//        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
